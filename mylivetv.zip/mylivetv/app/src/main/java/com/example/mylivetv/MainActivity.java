package com.example.mylivetv;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    ImageButton atp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        atp=findViewById(R.id.imageButton);


    }

    public void tennistv(View view) {
        Toast.makeText(this, "Streaming ATP Tennis TV", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this, atptennistv.class);
        startActivity(intent);
    }

    public void ddsports(View view) {
        Toast.makeText(this, "Streaming DD Sports", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this, ddsports.class);
        startActivity(intent);
    }
    public void btsports(View view) {
        Toast.makeText(this, "Streaming BT Sports", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this, btsports.class);
        startActivity(intent);
    }

    public void ndtv(View view) {
        Toast.makeText(this, "Streaming NDTV", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this, ndtv.class);
        startActivity(intent);
    }


    public void indiatoday(View view) {
        Toast.makeText(this, "Streaming INDIA TODAY", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this, indiatoday.class);
        startActivity(intent);
    }

    public void republictv(View view) {
        Toast.makeText(this, "Streaming REPUBLIC TV", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this, republictv.class);
        startActivity(intent);
    }

    public void discovery(View view) {
        Toast.makeText(this, "Streaming Discovery", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this, discovery.class);
        startActivity(intent);
    }

    public void nasa(View view) {
        Toast.makeText(this, "Streaming NASA", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this, nasatv.class);
        startActivity(intent);
    }

    public void exploreafrica(View view) {
        Toast.makeText(this, "Streaming Explore Africa", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this, exploreafrica.class);
        startActivity(intent);
    }

    public void asianetkan(View view) {
        Toast.makeText(this, "Streaming AsiaNet Kannada", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this, asianetkan.class);
        startActivity(intent);
    }

    public void tv9kan(View view) {
        Toast.makeText(this, "Streaming TV9 Kannada", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this, tv9kannada.class);
        startActivity(intent);
    }

    public void newsfirstkan(View view) {
        Toast.makeText(this, "Streaming NewsFirst Kannada", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this, neswfirstkannada.class);
        startActivity(intent);
    }
}